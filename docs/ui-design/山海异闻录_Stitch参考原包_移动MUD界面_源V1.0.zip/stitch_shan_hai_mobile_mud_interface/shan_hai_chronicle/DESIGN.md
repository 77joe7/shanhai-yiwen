---
name: Shan Hai Chronicle
colors:
  surface: '#17130f'
  surface-dim: '#17130f'
  surface-bright: '#3d3833'
  surface-container-lowest: '#110e0a'
  surface-container-low: '#1f1b17'
  surface-container: '#231f1b'
  surface-container-high: '#2e2925'
  surface-container-highest: '#39342f'
  on-surface: '#eae1da'
  on-surface-variant: '#cec5b9'
  inverse-surface: '#eae1da'
  inverse-on-surface: '#34302b'
  outline: '#979085'
  outline-variant: '#4c463d'
  surface-tint: '#d5c5a8'
  primary: '#fff2de'
  on-primary: '#392f1b'
  primary-container: '#e6d5b8'
  on-primary-container: '#685c45'
  inverse-primary: '#695d46'
  secondary: '#ffb4a8'
  on-secondary: '#690000'
  secondary-container: '#920703'
  on-secondary-container: '#ff9a8a'
  tertiary: '#fff1df'
  on-tertiary: '#412d00'
  tertiary-container: '#f5d294'
  on-tertiary-container: '#735927'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#f2e0c3'
  primary-fixed-dim: '#d5c5a8'
  on-primary-fixed: '#231a08'
  on-primary-fixed-variant: '#504530'
  secondary-fixed: '#ffdad4'
  secondary-fixed-dim: '#ffb4a8'
  on-secondary-fixed: '#410000'
  on-secondary-fixed-variant: '#920703'
  tertiary-fixed: '#ffdea6'
  tertiary-fixed-dim: '#e4c285'
  on-tertiary-fixed: '#271900'
  on-tertiary-fixed-variant: '#5a4312'
  background: '#17130f'
  on-background: '#eae1da'
  surface-variant: '#39342f'
typography:
  display-title:
    fontFamily: Noto Serif
    fontSize: 36px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: 0.1em
  headline-lg:
    fontFamily: Noto Serif
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  headline-lg-mobile:
    fontFamily: Noto Serif
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
  body-narrative:
    fontFamily: Literata
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.8'
  body-sm:
    fontFamily: Literata
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.6'
  label-caps:
    fontFamily: Source Serif 4
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.2em
spacing:
  unit: 4px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
  margin-edge: 20px
  gutter: 12px
---

## Brand & Style

This design system establishes a digital manuscript aesthetic, blending **Minimalism** with **High-Contrast** editorial elements. It is designed for a mobile-first MUD (Multi-User Dungeon) experience rooted in the "Classic of Mountains and Seas." 

The UI evokes the feeling of a scholar's desk—ancient, mystical, and focused. The interface prioritizes text-based immersion through heavy whitespace, high-contrast legibility, and delicate structural lines. The design avoids heavy textures in favor of clean, symbolic representations that allow the player's imagination to fill in the world.

- **Atmosphere:** Scholarly, ancient, authoritative.
- **Visual Strategy:** Dark parchment surfaces with sharp, calligraphic accents.
- **Experience:** Low cognitive load, high narrative immersion.

## Colors

The palette is derived from traditional Chinese ink wash paintings and aged silk scrolls.

- **Primary (#e6d5b8):** "Old Silk." Used for all primary narrative text and interactive icons.
- **Secondary (#8b0000):** "Cinnabar." Reserved for combat, critical warnings, and significant historical markers.
- **Tertiary (#c4a46a):** "Burnished Gold." Used for secondary UI details, borders, and subtle progress indicators.
- **Neutral (#1a1612):** "Ink Stone." The base canvas color, providing deep contrast for the text.

**Functional Accents:**
- **Health:** #8b0000 (Cinnabar)
- **Stamina:** #2e4d3e (Jade Green)
- **Experience:** #c4a46a (Gold)

## Typography

The typography system relies on a hierarchy of serifs to maintain a literary tone.

- **Display & Headlines:** Use **Noto Serif** for a classical, structured feel. Large titles should use increased letter spacing to mimic traditional block printing.
- **Narrative Text:** **Literata** is used for the core game log. The generous line height (1.8) ensures readability during long sessions of descriptive text on mobile screens.
- **Labels & System Info:** **Source Serif 4** provides a sturdy, professional contrast for character stats, buttons, and metadata.

## Layout & Spacing

The layout follows a **Fluid Grid** model focused on a central vertical scroll for the narrative log, with sticky headers and footers for status and navigation.

- **The Chronicle Log:** The main content area uses a 20px side margin to ensure text doesn't touch the screen edge.
- **Rhythm:** Vertical spacing is generous. Paragraphs in the game log are separated by `stack-lg` to allow the reader's eye to rest.
- **Mobile Reflow:** On mobile, sidebars collapse into a drawer menu. The character status bar is pinned to the top, utilizing a horizontal 3-column distribution for Health, Stamina, and Spirit.

## Elevation & Depth

This design system avoids shadows in favor of **Tonal Layers** and **Low-Contrast Outlines**.

- **Surface Layers:** The background (#1a1612) is the lowest layer. "Parchment" containers use a slightly lighter shade of the neutral color or a very subtle gradient to indicate separation.
- **Borders:** Depth is created through delicate 1px borders using the Tertiary (#c4a46a) color at 30% opacity.
- **Dividers:** Horizontal rules are used frequently to separate narrative beats. These should be stylized—tapered at the ends to resemble a brush stroke.

## Shapes

The design system employs **Sharp (0)** roundedness. 

Right angles reflect the structure of traditional woodblock printing and scroll frames. To avoid a "modern" feel, never use rounded corners on buttons or containers. 

Instead of roundedness, use "clipped corners" or double-line borders to create visual interest for featured components like character portraits or map containers.

## Components

- **Buttons:** Rectangular with a 1px border. The primary state is ghost-style (border and text in #e6d5b8), while the active/pressed state fills the background with #e6d5b8 and flips text to #1a1612.
- **Narrative Cards:** Used for item descriptions or encounter popups. Features a 1px #c4a46a border and a subtle top-center stylized icon.
- **Status Bars:** Thin, horizontal bars. The "fill" is a solid block of color (Cinnabar for HP), and the "empty" track is a dark, desaturated version of the same hue. No gradients or rounded ends.
- **Input Fields:** A simple line at the bottom of the screen (similar to a terminal) with a blinking block cursor. Text is entered directly onto the "Ink Stone" background.
- **Map Markers:** Stylized, geometric symbols (e.g., a simple triangle for a mountain, a circle for a city). These are rendered in #e6d5b8 to pop against the dark background.
- **Chips/Tags:** Used for character traits or status effects. Enclosed in square brackets `[Trait]` rather than a background pill, maintaining the text-centric look.